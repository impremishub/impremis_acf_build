<div class="page-header">
  <h1><?php echo App::title(); ?></h1>
</div>
